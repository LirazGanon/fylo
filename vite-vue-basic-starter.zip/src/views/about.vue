<template>
    <section class="">
        <h1>About</h1>
        <!-- ICONS -->
        <span class="material-symbols-outlined">
            check
        </span>
        <span class="material-symbols-outlined">
            close
        </span>
        <span class="material-symbols-outlined">
            circle
        </span>
      
    </section>
</template>
<script>
export default {
    name: 'about'
}
</script>

